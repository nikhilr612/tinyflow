# tinyflow Project — Session Summary & Continuation Guide

Written to compact a long Claude Code session (2026-09-12 → 09-14). Branch
`feat/pixel-unet` has the simplified/current code; `exp/aux-loss-campaign`
archives every experiment (including dropped variants) for reference.
Repo already contains a detailed `HANDOFF.md` and `experiments/METHODS.md` —
this document is a higher-level map of *how we got there* and *what's next*.

## 0. Project goal
`tinyflow`: from-scratch flow-matching image generator (JAX/Equinox), originally
64×64 anime faces, unconditional. Goal evolved into: find real inductive biases
that improve generation, understand *why* certain things helped/failed, produce
a rigorous paper-style writeup, and generalize the recipe to a second dataset
(CelebAMask-HQ).

## 1. Major arc of findings (chronological)

### 1.1 Auxiliary pixel-space losses on x̂ — CLOSED, negative
- Original code shipped a Sobel edge loss (L1, weight 0.1) + unused line/ink loss
  + a mask-prediction auxiliary head.
- **Theory** (derived and verified): flow-matching's population minimizer at
  every (x_t, t) is the conditional mean E[x_1|x_t]. Any loss on x̂ vs x_1 that
  isn't a function of (t, x_t) *alone* biases this minimizer (proof via
  E[wY|x_t] = E[Y|x_t] + Cov(w,Y|x_t)/E[w|x_t]). L1 losses additionally reward
  hedged (flatter) predictions (median vs mean).
- **Empirically**: shipped edge loss (weight 0.1) is actively *harmful* — reduces
  edge/ink content and worsens FID by ~7 points at 40 epochs, confirmed across
  9M and 37M models, 30–200 epochs.
- Tried and closed: sobel_l2 (inert), fm_edge/fm_ink/fm_eye re-weightings
  (fm_edge_sg unbiased version ties fm_edge — gain is ~0, not a real effect at
  length), mask-head auxiliary (worse with weight), global code via bottleneck
  pooling (literally switched on, zero effect — decoder wasn't short of global
  info), standard vs legacy skip connections (neutral at 9M, needs low LR at
  37M, kept legacy).
- **Decision**: `edge_weight` default changed to 0.0. This whole family is
  closed — don't re-run.

### 1.2 Bottleneck diagnosis
- FID floor (5000 real vs real): ~2.1.
- **Precision/recall** (Kynkäänniemi 2019): precision 0.52, **recall 0.15**
  (ceiling ~0.77/0.77). **Coverage, not fidelity, is the dominant gap** — 85% of
  real images have no generated neighbor. Worst samples are washed-out
  mode-averages, not broken faces.
- Per-region error analysis: mouth/nose recovered worst relative to their
  intrinsic variance (small, low-variance, high-frequency features get least
  loss weight).
- Colour: means correct, but chroma spread ~13-21% narrower than real, thin
  histogram tails (mean-seeking behavior).

### 1.3 Sampling-time guidance — POSITIVE, real but modest on its own
- Unary energy guidance (edge-mass deficit `E=relu(m_real - mean|Sobel(x̂)|)²`,
  gradient through network, RMS-normalized step): −3 to −8 FID depending on
  model size, λ≈0.02. No retraining needed. Precision↑, recall flat (mode-seeking).
- Interval-gated (KynkäänniemiÂ 2024 style) helps a bit more.
- σ_t²-scaled step (Tweedie-motivated) — same ceiling (~−2), the *energy* is the
  limiting factor, not the schedule.

### 1.4 **Autoguidance — BIG WIN, most promising direction**
- Karras et al. 2024 "bad version of itself": `v = v_good + w·(v_good − v_bad)`,
  bad = same architecture, less-trained checkpoint (e.g. 40-epoch confirm_rp
  as bad, 300-epoch best_model as good).
- Result: **FID 34.6 → 21.2** (w=1, full t-window) on the conditioned model —
  roughly 3× the gain of any energy-guidance variant, no retraining.
  w=2 overshoots/collapses. w=0.5 also strong (24.9).
- This is clearly the top lever discovered and deserves more exploration
  (finer w sweep, different "bad" checkpoints, combined with refinement).

### 1.5 Re-noise/refinement sampling (SDEdit-style)
- Re-noise finished sample to t0, re-solve ODE. t0=0.85 gave ~34.6→31.8 FID.
  Modest positive, stackable with guidance.

### 1.6 Mask-guided Region Pooling — MAJOR ARCHITECTURAL WIN (the headline result)
- **Problem observed**: model generates faces with mismatched left/right iris
  colors ("heterochromia" defect) ~30-40% of the time (real data ~5%).
- Root cause diagnosis: global bottleneck info was NOT missing (global-code
  experiment proved this — null result despite switching on). The defect is
  that two spatially separated regions (the eyes) are rendered independently
  by local convolutions with no coupling mechanism.
- **Solution**: `RegionPool` layer — for each semantic region k (face, eyes,
  mouth, [nose]) with soft mask m_k:
  ```
  pooled_k = Σ_p m_k(p)·h(p) / Σ_p m_k(p)      # mask-weighted mean, one vector/region
  h_out = h + Σ_k m_k ⊗ (W_k·pooled_k + b_k)   # zero-init W_k, broadcast back
  ```
  Applied at 16×16 and 32×32 decoder resolutions. Both irises painted from one
  shared pooled feature → forces agreement. Described as "masked attention
  with a single fixed query per region and uniform weights" — routing given by
  layout (not learned), only the linear map on the aggregate is learned.
  Zero-init = identity at init. ~0.4M extra params at width 64.
- Requires layout mask as *conditioning input* to the model (concatenated to
  x_t, +1 indicator channel for null/unconditional). Layouts sampled from a
  fitted prior at inference (`LayoutPrior` = point-distribution model:
  pose+shape decomposition of 28 landmarks, PCA + Dirichlet-process GMM,
  numpy-only sampler in `data/layouts.py`).
- **Result**: iris mismatch rate 34% → **6.6% → 6.25% (parallel/vectorized
  layer) → 4.7% (300-epoch)**, essentially at the real-data floor (5.0-5.9%).
  FID cost was small to moderate depending on training length/schedule (see
  below).
- Bonus: also gives strong **layout adherence/control** — the mask being
  reinjected at decoder resolution (SPADE-like mechanism) means the model
  follows given face/eye/mouth layout much more faithfully than a model
  conditioned only at the input (which gets "washed out" by GroupNorm/
  bottleneck, per the SPADE paper's observation). This became a second
  headline finding ("controllable layout").
- Later (this session) added a **nose channel** (cond_channels 3→4, disc mask
  at nose landmark): fixed the nose localization defect (placement error
  halved, detector confidence 0.61→0.74, FID −3). Dilated pooling for
  mouth/nose tried and found to be *no help* (dropped). Mouth rendering
  (not localization) remains the weakest region — likely addressable via
  autoguidance rather than more architecture.

## 2. Training dynamics / practical lessons
- **LR instability**: constant LR=1e-3 on the 37M model caused sudden loss
  divergence after ~50-100 epochs on both anime (region-pool run) and CelebA
  runs, and separately for mid-block-attention and standard-skip variants.
  Fix: warm-up (500 steps) + cosine decay to 1% of peak
  (`optax.warmup_cosine_decay_schedule`, `--init-lr`, `--warmup-steps`,
  `--lr-end-frac`).
- **Screening protocol matters**: 30-epoch FID comparisons are noisy (±4-5),
  and LR=3e-4 gives *lower loss but worse FID* than 1e-3 at short horizons —
  loss and FID can disagree at short horizons. Established a real turning
  point near 200 cumulative epochs (~33k steps) for the 37M model; recipe:
  `just paper NAME 200 25` (one schedule segment, cosine ending at 200,
  FID every 25), then use `best_model.eqx` (best training-time FID) not
  final weights.
- **Late-epoch FID drift** on the region-pool model: NOT overfitting/
  memorization (verified — training loss keeps falling, and FID reference
  stats are the training set so memorization would *lower* FID, not raise
  it). Instead: as training continues, the model's dependence on RegionPool
  broadcasting grows (measured directly — contribution to x̂ triples, and
  network becomes unable to function without it), so it renders the *prior's*
  imperfect synthetic layout more literally — the prior-vs-real-layout FID
  gap widens (3.5 FID gap opened by epoch 300 vs ~0 at 40 epochs). Fix
  implied: better layout prior (real landmarks + jitter, or don't run past
  the FID-optimal checkpoint), not shorter/longer training per se.
- **16-step Dopri5 sampler** ≈ 64-step within 0.5 FID — use 16 for cheap
  screening always.
- GPU: 24GB card gets fully utilized; concurrent jobs OOM at FID evaluation
  unless capped (`XLA_PYTHON_CLIENT_MEM_FRACTION=0.47`); JAX preallocates 75%
  by default so `nvidia-smi` numbers overstate true working set.
- Off-the-shelf anime upscalers (Real-ESRGAN anime6B, x4plus, APISR,
  realesr-animevideov3) were tried purely for a paper showcase figure and
  **rejected**: they're trained on clean→degraded pairs and render the
  *generator's own errors* as confident, exaggerated detail. Native 64×64
  samples read more convincingly as anime. Decision: no upscaler in the
  paper.

## 3. Codebase state (branch `feat/pixel-unet`)
- Simplified/cleaned after the full campaign; dropped experiment code lives
  on `exp/aux-loss-campaign` (tagged `ckpt-9aef10c` archive of checkpoints in
  `runs/archive/9aef10c/`).
- Key files: `models/unet.py` (UNet w/ `cond_channels`, `region_pool`,
  `image_size` hparams; `RegionPool` class), `models/imagefm.py` (FM loss +
  conditioning, no aux losses), `data/layouts.py` (landmark parametrization +
  numpy `LayoutPrior`), `data/celebamask.py` (new, CelebAMask-HQ preprocessing
  + curation), `training.py` (`MaskedSampler` for conditioned FID eval),
  `main.py` (`anime`/`--dataset-name celeba` command), `justfile` (task
  runner — `just paper NAME EPOCHS EVERY` is the main pipeline),
  `experiments/` (bottleneck.py, guidance.py, autoguide.py, refine.py,
  landmark_prior.py, mask_following.py, eye_consistency.py, cond_eval.py,
  compare_samples.py, extract_landmarks.py), `generate_figures.py` (paper
  figures + showcase), `paper/main.tex` (full ICLR-style writeup, builds
  clean, 14 pages), `experiments/METHODS.md` (detailed experimental log),
  `HANDOFF.md` (detailed pending-work doc — **read this first** when
  resuming), `experiments/CELEBAMASK_SCOPE.md` (plug-and-play audit for 2nd
  dataset).

## 4. Best results so far
| checkpoint | FID (16-step) | iris mismatch |
|---|---|---|
| plain unconditioned wide, 200ep | 31.4-32.0 | ~35% (not fixed) |
| + edge guidance λ=0.02 | 28.1 | — |
| region-pool conditioned, 40ep (parallel layer) | 52.1/51.4 (prior/real) | 6.25% |
| region-pool conditioned, 200ep (wide_rp_200, best@ep124) | 32.9/31.4 | 4.3% |
| region-pool conditioned, 300ep (3 segments, drift) | 37.8/34.2 | 4.7% |
| + edge guidance λ=0.02 on best_model | 32.5 | — |
| **+ autoguidance w=1 (bad=confirm_rp)** | **21.2** | (not yet re-measured) |
| schedule-matched plain unconditioned control (ctrl_sched, 200ep) | 29.3 | n/a |

Autoguidance is the standout: applied to the region-pool conditioned model it
beats every other approach tried, including the plain unconditioned baseline,
while retaining the iris-fix and layout-control benefits.

## 5. Second dataset: CelebAMask-HQ
- Downloaded (30k images, 256px, 19-class label maps), preprocessed to 64×64
  and 128×128 arrays with 4-channel masks (face/eyes/mouth/nose) built from
  label-map unions; curated ~1.8% (duplicates, empty-eyes, empty-mouth/nose,
  bad alignment, greyscale) — kept 26-29k depending on threshold; last 3000
  ids reserved as held-out layout eval bank (ground-truth masks used instead
  of a fitted prior, per instruction — CelebA has real masks so no need for
  landmark-prior sampling).
  UNet updated to place RegionPool layers by *resolution* not hardcoded level
  index, so both 64 and 128px work (`--image-size 128 --n-blocks 5`).
- Note: at 64px CelebA eyes are only ~35px apart total (14× smaller than
  anime eyes) — the iris-consistency mechanism is barely testable there. At
  128px eyes are ~140px, comparable to anime — this is the meaningful test.
- **In progress when session ended**: 64px CelebA training run (100 epochs)
  hit the same LR=1e-3 divergence pattern around epoch 24 (loss spiked
  0.043→0.285). Was being restarted with lower LR / from checkpoint when the
  session was cut off (Claude Code access was disabled by org policy at the
  very end).
- 128px arrays are already built and ready to go once 64px is stable.

## 6. Immediate next steps (resume here)
1. **Finish CelebA 64px run** — restart from `best_model.eqx` (~epoch 24) with
   the anime lesson applied: warm-up + cosine schedule from the start this
   time (don't wait for a divergence). Recipe:
   ```
   uv run main.py anime --dataset-name celeba --cond-channels 4 --region-pool 1 \
     --base-channels 64 --n-epochs 100 --eval-every 25 --cond-dropout 0 \
     --outpath runs/celeba_rp_100/model.eqx
   ```
   (warmup/cosine are now default-on via `TrainConfig`).
2. Run the plain-CelebA and region_pool=0 controls for comparison.
3. Once 64px is validated, run 128px CelebA (region-pool vs control) — this
   is the real test of whether region-pooling generalizes to real faces where
   eyes are a comparable size to anime.
4. **Push further on autoguidance** — it's the best lever found:
   - finer w sweep around 0.5-1.5
   - try different "bad" checkpoints (earlier epoch of *same* run vs a
     different smaller/weaker architecture)
   - combine with refinement (t0~0.85) and/or edge guidance
   - re-measure iris mismatch + mask-following + precision/recall under
     autoguidance to confirm no regression
   - consider autoguidance on the *plain* (non-conditioned) model too
5. Re-score mouth rendering quality post-autoguidance (mouth landmark
   confidence gap 0.72 vs 0.85 real was the one defect the RegionPool nose
   channel didn't fix — hypothesis: autoguidance's global correction may fix
   this without more architecture).
6. Investigate/fix the layout-prior quality (real-landmark + jitter sampling
   instead of pure DP-GMM) to close the prior-vs-real FID gap that drives the
   late-training drift.
7. Fold every new number into `experiments/METHODS.md` and `paper/main.tex`
   (§4 guidance, §5 bottleneck, §7.3/7.4/7.5 layout & region-pool & refinement,
   §13 results) — keep the paper as the single source of truth.
8. `HANDOFF.md` already has fine-grained recipes/gotchas for reproducing each
   stage — consult it for exact commands, file paths, and known traps (concurrent
   GPU jobs OOM, sequential-vs-parallel RegionPool checkpoint incompatibility,
   detector environment location, etc).

## 7. Handy commands (all used successfully in this session)

### Setup / gates
```sh
uv sync --locked --all-extras --dev     # install, matches CI
just check                              # ruff check + ty check (both CI gates)
just fmt                                # ruff check --fix + ruff format
```

### Basic training
```sh
# Single arm, N epochs, FID only at the end (screening default now):
just train NAME EPOCHS [ARGS...]
# e.g. just train exp_x/edge0 30 --edge-weight 0.0

# Detached/background (survives Claude session ending — verified: process
# group has no parent tie to the CLI shell):
just train-bg NAME EPOCHS [ARGS...]

# Two arms concurrently, memory-capped so both can FID-eval without OOM
# (only reliable for the 9M model; the 37M model's FID thrashes when paired —
# run those one at a time instead):
just pair EPOCHS A "ARGS" B "ARGS"
XLA_PYTHON_CLIENT_MEM_FRACTION=0.47 uv run main.py anime ...   # manual cap

# Arms one after another (right choice for the 37M model):
just queue EPOCHS A "ARGS" B "ARGS" ...
```

### The full "paper" pipeline (train → eval → figures)
```sh
# NAME EPOCHS EVAL_EVERY [extra main.py flags]; uses the current best recipe
# (base_channels=64, cond_channels=3/4, region_pool=1, cond_dropout=0,
# min_landmark_score=0.3) baked into the `model_args` var in the justfile:
just paper wide_rp_300 300 50
just paper wide_rp_200 200 25                     # the recommended protocol
just paper smoke 2 1 --base-channels 8 --time-embedding-dim 32   # smoke test, ~2 min

# Resume a run whose weights already exist (same architecture, fresh optimiser):
uv run main.py anime --outpath runs/NAME/model.eqx --n-epochs 200 \
    --eval-every 25 --early-stop-patience 0 --seed 49 \
    --init-from runs/OLD_RUN/model.eqx <model_args>
# NB: set --n-epochs to the *remaining* epochs so the cosine schedule ends
# where the run ends — don't chain warm restarts; each one re-raises the LR
# to peak and costs several epochs of regression.
```

### CelebA dataset
```sh
uv run python data/celebamask.py                       # build 64px arrays
uv run python data/celebamask.py --size 128             # build 128px arrays

uv run main.py anime --dataset-name celeba --cond-channels 4 --region-pool 1 \
    --base-channels 64 --n-epochs 100 --eval-every 25 --cond-dropout 0 \
    --outpath runs/celeba_rp_100/model.eqx

uv run main.py anime --dataset-name celeba --image-size 128 --n-blocks 5 \
    --base-channels 64 --cond-channels 4 --region-pool 1 --cond-dropout 0 \
    --n-epochs 200 --eval-every 25 --fid-batch-size 64 \
    --outpath runs/celeba128_rp_200/model.eqx
```

### Watching / reading results
```sh
just watch                              # live progress bar + GPU load of every running job
just fid runs/exp_x runs/exp_y          # FID table across arms/experiments
just samples OUT.png "name=path.eqx" "name2=path2.eqx"   # labelled sample grid, shared noise
just eyes "name=ckpt" "name2=ckpt2"     # iris-mismatch ("heterochromia") rate per checkpoint
just eval CKPT                          # FID (prior/real layouts) + iris mismatch, one checkpoint
just figures runs/NAME                  # paper figures + showcase.png for a finished run
just colors CKPT                        # colour statistics vs. real data
```

### Offline / no-GPU-needed diagnostics
```sh
JAX_PLATFORMS=cpu uv run python experiments/aux_signal.py         # (archived branch only)
uv run python experiments/landmark_prior.py                       # fit + sanity-check the layout prior
uv run python experiments/mask_following.py sample "name=ckpt" ... --n 512
uv run python experiments/mask_following.py score                 # needs the detector env, see below
```

### Sampling-time guidance & autoguidance (the two big levers)
```sh
# Unary energy guidance (edge-mass deficit), lambda + optional t-window:
just guidance CKPT --n-fid 2000 --lams 0,0.02,0.05,0.1,0.2
uv run python experiments/guidance.py --checkpoint CKPT \
    --lams 0,0.02,0.05 --energies edge,ink,eye --intervals 0-1,0.3-0.9,0.5-1
uv run python experiments/guidance.py --checkpoint CKPT --scale sigma2 \
    --lams 0,0.005,0.01,0.02,0.05      # Tweedie/sigma_t^2-scaled step

# Autoguidance — the standout result (FID 34.6 -> 21.2 at w=1):
uv run python experiments/autoguide.py --good runs/wide_rp_300/best_model.eqx \
    --bad runs/confirm_rp/model.eqx --ws 0,0.5,1,2 --intervals 0-1,0.3-1

# Re-noise/refinement (SDEdit-style):
uv run python experiments/refine.py --checkpoint CKPT --t0s 0,0.5,0.7,0.85
```

### Bottleneck / precision-recall analysis
```sh
uv run python experiments/bottleneck.py --checkpoint CKPT --n-fid 5000
uv run python experiments/bottleneck.py --checkpoint CKPT --skip-sampler \
    --outdir runs/ablation/bottleneck_final    # skip the slow guided-sampler stage
# if OOM in the guided stage, lower the batch size passed to that
# generate(...) call (was bumped from 256 -> 64 successfully)
```

### Detector environment (landmarks / mask-following — needs its own env)
```sh
# torch/mmdet env lives at a job-scratch path, NOT a project dependency:
~/.claude/jobs/<job_id>/tmp/det/bin/python experiments/extract_landmarks.py
~/.claude/jobs/<job_id>/tmp/det/bin/python experiments/mask_following.py score
# (this path is fragile / may be garbage-collected — recreate the env with
# anime-face-detector + mmdet + torch + cv2 if it's gone)
```

### Housekeeping
```sh
git branch --show-current
git checkout -b exp/archive-branch-name       # archive a full experiment tree before simplifying
git add -A && git commit -q -m "Archive: ..."
git tag ckpt-<short-sha>                      # tag a commit whose checkpoints/results are referenced
cp -r runs/exp_* runs/archive/<tag>/          # physically back up checkpoints before risky edits

cd paper && latexmk -pdf -interaction=nonstopmode main.tex   # rebuild the paper
```

## 7b. Resuming checkpoints & LR schedule tuning (precedent: `wide_rp_300`)

This deserves its own section because it caused real pain (a divergence, an
OOM-triggered kill, and a confounded final result) and the lessons are easy to
forget.

### What went wrong, in order (the precedent)
1. First attempt at `wide_rp_300` used **constant LR = 1e-3** (the old
   default). Trained fine for ~80 epochs, then loss jumped from 0.0784 to
   0.2837 in a single epoch and samples were destroyed. Same failure mode
   independently hit the mid-block-attention run and a standard-skip-connection
   run — **constant 1e-3 is at the edge of stability for the 37M model once
   extra modules (region pooling, attention, etc.) are added.**
2. Fix: added `warmup_cosine_decay_schedule` to `TrainConfig`/`main.py` and
   **resumed from the last good checkpoint** (epoch 49) via `--init-from`,
   with a *fresh* optimiser state (Adam moments reset, LR schedule restarts
   from 0).
3. Second segment (49 epochs) was killed mid-run — not by divergence, but by
   an unrelated **cuSolver OOM** caused by a second GPU job (an eye-chroma
   diagnostic script) contending for memory during FID eval. Lesson: *never*
   run anything else on the GPU while a training job is between epochs near
   an FID checkpoint.
4. Resumed again from epoch 98 for the final 200-epoch segment.
5. Net effect: the "300-epoch" run was actually **three schedule segments**,
   each with its own warm-up-to-peak-LR ramp. This is a real confound — every
   restart re-raises LR to peak, costing several epochs of visible regression
   (FID 34.9 → 47.8 right after the second restart) before the cosine decay
   recovers it. The *reported* final numbers are legitimate, but the
   *trajectory* is not comparable to a single continuous schedule, and it
   likely amplified the late-training FID drift (see §1.6/§6).

### Commands (exact precedent)
```sh
# Fresh run with schedule (now the default — warmup_steps=500, lr_end_frac=0.01):
uv run main.py anime --outpath runs/NAME/model.eqx --n-epochs 200 \
    --eval-every 25 --early-stop-patience 0 --seed 49 \
    --init-lr 1e-3 --warmup-steps 500 --lr-end-frac 0.01 <model_args>

# Resume from an existing checkpoint (same architecture required — raises if
# hparams differ):
uv run main.py anime --outpath runs/NAME/model.eqx --n-epochs <REMAINING_EPOCHS> \
    --eval-every 25 --early-stop-patience 0 --seed 49 \
    --init-from runs/OLD_RUN/model.eqx <model_args>
```

### Rules of thumb established this session
- **Always use the warm-up + cosine schedule for any run with region pooling,
  attention, or other add-on modules on the 37M model.** Constant LR is only
  safe for the plain (no-extras) architecture, and even there it's untested at
  length beyond ~200 epochs.
- **`--n-epochs` on a resumed run must be the *remaining* epoch count**, not
  the original total — the schedule's `decay_steps` is computed from
  `n_epochs * batches_per_epoch`, so it needs to know how many steps are left
  in *this* segment for the cosine to land correctly at the end.
- **Do not chain more than one warm restart if avoidable.** If a run must be
  resumed, treat the resumed segment as its own mini-schedule and say so
  explicitly in any write-up (as METHODS.md §7.4 does) — don't present the
  concatenated FID curve as if it came from one continuous schedule.
- **Use `best_model.eqx`, not final weights, as "the" result.** The training
  loop already tracks the best training-time FID checkpoint. For `wide_rp_300`
  this was epoch 99-of-segment-3 (cumulative ~199, FID 34.9) vs the final
  epoch's 37.5-37.8 — the run's true peak was ~100 epochs before it stopped.
- **Recipe going forward** (established as the standard protocol): one
  segment, `just paper NAME 200 25` (200 epochs, cosine ending at 200, FID
  every 25), no interruptions, then `just eval runs/NAME/best_model.eqx`.
- **Verify resumed weights are continuous** by checking the first post-resume
  epoch's loss matches where the old run left off (done in practice: resumed
  run's first epoch loss 0.0784 exactly matched the collapsed run's epoch-79
  value, confirming the `--init-from` load was correct before trusting the
  rest of the run).
- Keep every segment's checkpoint and `losses.json` on disk
  (`runs/NAME_epNN.eqx`, `runs/NAME_losses_segK.json`) rather than overwriting
  — needed to reconstruct the true training curve and to debug exactly this
  kind of multi-segment confound after the fact.

## 8. Closed / do-not-re-run list
Any pixel-space loss on x̂ vs x_1 (L1/L2, gated or not, FM re-weightings,
mask-prediction head auxiliary), global code (bottleneck pooling broadcast),
standard vs legacy skip connections (tested, neutral/needs-tuning, not worth
revisiting), dilated region pooling, palette/structured-output-head ideas
(shelved as precision-side bets with representational risk), off-the-shelf
upscalers for the paper, batch size 256 (slower than 128 — GPU already
saturated), sampler steps beyond 16 (no FID benefit).
