# Bottleneck analysis: `runs/wide_rp_300/best_model.eqx`

## Where: prediction error by region (training-time view)

Squared error of x_hat vs x_1, mean over 512 real pairs; right half divided by the dataset's per-pixel variance (1.0 = as bad as the dataset mean).

| t | face | eyes | mouth | hair/background | face /var | eyes /var | mouth /var | hair/background /var |
|---|---|---|---|---|---|---|---|---|
| t=0.3 | 0.0568 | 0.0952 | 0.0267 | 0.0684 | 0.3179 | 0.3029 | 0.3267 | 0.2253 |
| t=0.5 | 0.0327 | 0.0550 | 0.0171 | 0.0359 | 0.1872 | 0.1760 | 0.2180 | 0.1194 |
| t=0.7 | 0.0143 | 0.0236 | 0.0088 | 0.0146 | 0.0868 | 0.0760 | 0.1180 | 0.0491 |
| t=0.9 | 0.0032 | 0.0049 | 0.0023 | 0.0030 | 0.0213 | 0.0160 | 0.0320 | 0.0103 |

## Where: generated vs real local statistics (sampling-time view)

Relative difference per region (negative = generated has less).

| statistic | face | eyes | mouth | hair/background |
|---|---|---|---|---|
| edge mass | -0.106 | -0.106 | -0.099 | -0.090 |
| luma std | -0.117 | -0.112 | -0.107 | -0.102 |
| chroma std | -0.098 | -0.122 | -0.086 | -0.093 |

## What kind of gap

FID floor (5000 real vs real stats): **2.1**

| sampler | precision | recall |
|---|---|---|
| plain sampler | 0.471 | 0.125 |
| edge guidance lam=0.02 | 0.485 | 0.108 |
| real vs real (ceiling) | 0.774 | 0.765 |

`worst_samples.png` / `best_samples.png`: samples farthest from / closest to the real Inception manifold.
