# Landmark prior checks

Fitted on 20519 layouts (mean score >= 0.7), mirror-augmented; PCA 32 comps (99% var); DP-GMM 16 active of 16 components.

| measure | real mean / std | dp-gmm mean / std | kde mean / std |
|---|---|---|---|
| eye spacing | 0.769 / 0.055 | 0.768 / 0.054 | 0.769 / 0.057 |
| eye size A | 0.356 / 0.064 | 0.367 / 0.062 | 0.369 / 0.066 |
| eye size B | 0.383 / 0.062 | 0.369 / 0.063 | 0.369 / 0.067 |
| openness A | 0.604 / 0.193 | 0.583 / 0.175 | 0.587 / 0.189 |
| openness B | 0.564 / 0.171 | 0.582 / 0.176 | 0.588 / 0.188 |
| |open A - open B| | 0.137 / 0.131 | 0.131 / 0.122 | 0.148 / 0.140 |
| mouth width | 0.185 / 0.115 | 0.185 / 0.108 | 0.182 / 0.113 |
| face width | 1.424 / 0.092 | 1.422 / 0.091 | 1.422 / 0.092 |
| off-canvas frac | 0.003 / 0.055 | 0.001 / 0.032 | 0.004 / 0.061 |

Rasteriser check: IoU of re-rasterised real landmarks vs stored masks, per channel (face, eyes, mouth) = 0.987, 0.948, 0.643.

Mirror-correspondence check: max per-point residual 0.0852 (median 0.0463) at points [1, 3, 7, 8, 9]; a large value flags a wrong left/right pairing in `mirror`.

Grids: `masks_real.png` (over images), `masks_gmm.png`, `masks_kde.png` (R = face, G = eyes, B = mouth); `landmarks_mean.png` for the point layout.
