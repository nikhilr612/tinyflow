#!/usr/bin/env bash
# 1. Confirm the region-pooling result on the vectorised layer (same recipe as
#    runs/exp_cond/nodrop_rp: 40 epochs, FID at the end).  2. If the iris-mismatch
#    rate with prior layouts is under 10 %, run the 300-epoch paper pipeline.
cd /home/workstation10/Documents/tinyflow
just train confirm_rp 40 --base-channels 64 --cond-channels 3 --cond-dropout 0.0 --region-pool 1 \
    --min-landmark-score 0.3 > /dev/null 2>&1
just eval runs/confirm_rp/model.eqx > runs/confirm_rp/cond_eval.log 2>&1
hetero=$(python3 -c "import json; print(json.load(open('runs/confirm_rp/cond_eval.json'))['prior']['hetero'])")
echo "confirm_rp iris mismatch (prior layouts): $hetero %" > runs/confirm_rp/VERDICT
if python3 -c "import sys; sys.exit(0 if $hetero < 10 else 1)"; then
    echo "PASS -> starting paper run" >> runs/confirm_rp/VERDICT
    just paper wide_rp_300 300 50 > runs/paper.log 2>&1
else
    echo "FAIL -> paper run not started" >> runs/confirm_rp/VERDICT
fi
