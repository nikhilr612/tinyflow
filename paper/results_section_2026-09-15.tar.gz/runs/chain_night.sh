#!/usr/bin/env bash
# Overnight queue (2026-09-14).  Each stage waits for the previous; every stage
# writes under runs/ablation/<name> or runs/<name>.  Nothing else may use the GPU.
cd /home/workstation10/Documents/tinyflow
log() { echo "$(date +%H:%M) $*" >> runs/chain_night.log; }
until grep -q "^wrote" runs/ablation/guidance_final.log; do sleep 30; done
log "guidance sweep done"

# 1. precision / recall etc. on the final checkpoint (guided batch fixed at 64)
uv run python experiments/bottleneck.py --checkpoint runs/wide_rp_300/best_model.eqx --skip-sampler \
    --outdir runs/ablation/bottleneck_final > runs/ablation/bottleneck_final.log 2>&1
log "bottleneck done"

# 2. mask-following score: RP final vs the no-RP conditional model, real as ceiling
uv run python experiments/mask_following.py sample \
    "rp_best=runs/wide_rp_300/best_model.eqx" "no_rp=runs/exp_cond/nodrop/model.eqx" \
    > runs/ablation/mask_following.log 2>&1
/home/workstation10/.claude/jobs/211c1fe7/tmp/det/bin/python experiments/mask_following.py score \
    >> runs/ablation/mask_following.log 2>&1
log "mask following done"

# 3. re-noise-and-re-solve refinement sweep on the best checkpoint
uv run python experiments/refine.py --checkpoint runs/wide_rp_300/best_model.eqx \
    --t0s 0,0.5,0.7,0.85 > runs/ablation/refine.log 2>&1
log "refine done"

# 4. schedule-matched unconditioned control: 200 epochs, cosine, FID every 25
just train ctrl_sched 200 --base-channels 64 --eval-every 25 > /dev/null 2>&1
log "ctrl_sched done"

# 5. the conditioned recipe on the recommended protocol (one segment, cosine to 200)
just paper wide_rp_200 200 25 > runs/paper_200.log 2>&1
log "wide_rp_200 done"
echo ALL_DONE >> runs/chain_night.log
